
package com.usa.reto3.Interface;

import com.usa.reto3.Model.Category;
import org.springframework.data.repository.CrudRepository;


public interface interfaceCategory extends CrudRepository<Category, Integer>{
    
}
