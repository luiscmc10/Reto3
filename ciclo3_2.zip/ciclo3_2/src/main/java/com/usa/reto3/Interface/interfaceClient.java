
package com.usa.reto3.Interface;

import com.usa.reto3.Model.Client;
import org.springframework.data.repository.CrudRepository;


public interface interfaceClient extends CrudRepository<Client, Integer>{
    
}
