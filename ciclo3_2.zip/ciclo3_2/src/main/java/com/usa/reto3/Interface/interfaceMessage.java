
package com.usa.reto3.Interface;

import com.usa.reto3.Model.Message;
import org.springframework.data.repository.CrudRepository;


public interface interfaceMessage extends CrudRepository<Message, Integer>{
    
}
