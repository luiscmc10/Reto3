
package com.usa.reto3.Interface;

import com.usa.reto3.Model.Reservation;
import org.springframework.data.repository.CrudRepository;


public interface interfaceReservation extends CrudRepository<Reservation, Integer>{
    
}
