
package com.usa.reto3.Interface;

import com.usa.reto3.Model.Skate;
import org.springframework.data.repository.CrudRepository;


public interface interfaceSkate extends CrudRepository<Skate, Integer>{
    
}
